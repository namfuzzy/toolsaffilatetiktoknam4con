function initLogsPage(){console.log('initLogsPage run');}

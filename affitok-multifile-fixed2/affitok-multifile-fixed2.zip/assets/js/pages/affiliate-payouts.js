function initAffPayoutsPage(){console.log('initAffPayoutsPage run');}

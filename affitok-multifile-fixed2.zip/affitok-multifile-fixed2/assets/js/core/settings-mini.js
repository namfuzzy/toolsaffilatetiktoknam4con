// assets/js/core/settings-mini.js
// Bảng cài đặt API + Proxy, hỗ trợ Refresh model (Gemini & Perplexity) qua GAS.
// Yêu cầu: window.ENV, window.KV đã sẵn sàng.
(function () {
  const h = (tag, attrs = {}, html = "") => {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k in el) el[k] = v; else el.setAttribute(k, v);
    }
    if (html) el.innerHTML = html;
    return el;
  };
  const getKV = (k, d="") => (window.KV?.get(k, d) ?? d);
  const setKV = (k, v) => { try { window.KV?.set(k, v) } catch {} };

  async function callProxy({ proxyUrl, provider, apiKey, body }) {
    if (!proxyUrl) throw new Error("Chưa cấu hình Proxy URL (GAS).");
    const res = await robustFetch(proxyUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ provider, apiKey, body })
    });
    return res.json();
  }

  function ensureDatalist(inputId, listId) {
    let input = document.getElementById(inputId);
    if (!input) return null;
    let list = document.getElementById(listId);
    if (!list) {
      list = document.createElement("datalist");
      list.id = listId;
      document.body.appendChild(list);
    }
    input.setAttribute("list", listId);
    return list;
  }

  function renderPanel() {
    const dock = h("div");
    dock.style = [
      "position:fixed","right:16px","bottom:16px","z-index:99999",
      "display:flex","align-items:center","gap:8px",
      "font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, sans-serif"
    ].join(";");

    const openBtn = h("button", { className: "btn btn-secondary", title: "Cài đặt API & Proxy" }, "⚙ API");

    const dlg = h("div");
    dlg.style = [
      "position:fixed","right:16px","bottom:64px","z-index:100000",
      "width:380px","max-width:90vw",
      "background:#111827","color:#fff",
      "border:1px solid #334155","border-radius:10px",
      "padding:14px","display:none","box-shadow:0 8px 30px rgba(0,0,0,.35)"
    ].join(";");

    dlg.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
        <strong>Cài đặt API</strong>
        <button id="ps-close" class="btn btn-secondary" style="padding:4px 8px">Đóng</button>
      </div>

      <label>Provider mặc định</label>
      <select id="ps-provider" class="form-control">
        <option value="gemini">Gemini</option>
        <option value="perplexity">Perplexity</option>
      </select>

      <div style="display:grid;grid-template-columns:1fr;gap:8px;margin-top:10px;">
        <div>
          <label>Proxy URL (GAS) — tùy chọn</label>
          <input id="ps-proxy" class="form-control" placeholder="https://script.google.com/macros/s/.../exec" />
        </div>

        <hr style="border-color:#334155">

        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px">
          <div style="flex:1">
            <label>Gemini API Key</label>
            <input id="ps-gemini-key" class="form-control" placeholder="AIza..." />
          </div>
          <button id="ps-gemini-refresh" class="btn btn-secondary" title="Lấy danh sách model Gemini" style="margin-top:20px">Refresh</button>
        </div>
        <div>
          <label>Gemini Model</label>
          <input id="ps-gemini-model" class="form-control" placeholder="vd: gemini-2.5-pro" />
        </div>

        <hr style="border-color:#334155">

        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px">
          <div style="flex:1">
            <label>Perplexity API Key</label>
            <input id="ps-pplx-key" class="form-control" placeholder="pplx-..." />
          </div>
          <button id="ps-pplx-refresh" class="btn btn-secondary" title="Lấy danh sách model Perplexity" style="margin-top:20px">Refresh</button>
        </div>
        <div>
          <label>Perplexity Model</label>
          <input id="ps-pplx-model" class="form-control" placeholder="vd: sonar-small-chat" />
        </div>
      </div>

      <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:12px;">
        <button id="ps-save" class="btn btn-primary">Lưu</button>
      </div>
    `;

    // datalist cho 2 ô model
    ensureDatalist("ps-gemini-model", "dl-gemini-models");
    ensureDatalist("ps-pplx-model", "dl-pplx-models");

    // mở panel
    openBtn.onclick = () => {
      const $ = (s) => dlg.querySelector(s);
      $("#ps-provider").value  = getKV("provider", window.ENV?.DEFAULT_PROVIDER || "gemini");
      $("#ps-proxy").value     = getKV("proxy_url", window.ENV?.PROXY_URL || "");
      $("#ps-gemini-key").value= getKV("gemini_key", window.ENV?.GOOGLE_API_KEY || "");
      $("#ps-gemini-model").value = getKV("gemini_model", window.ENV?.GEMINI_MODEL || "");
      $("#ps-pplx-key").value  = getKV("pplx_key", window.ENV?.PPLX_API_KEY || "");
      $("#ps-pplx-model").value= getKV("pplx_model", window.ENV?.PPLX_MODEL || "sonar-small-chat");
      dlg.style.display = "block";
    };

    // đóng
    dlg.querySelector("#ps-close").onclick = () => (dlg.style.display = "none");

    // lưu
    dlg.querySelector("#ps-save").onclick = () => {
      const $ = (s) => dlg.querySelector(s);
      setKV("provider", $("#ps-provider").value.trim());
      setKV("proxy_url", $("#ps-proxy").value.trim());
      setKV("gemini_key", $("#ps-gemini-key").value.trim());
      setKV("gemini_model", $("#ps-gemini-model").value.trim());
      setKV("pplx_key", $("#ps-pplx-key").value.trim());
      setKV("pplx_model", $("#ps-pplx-model").value.trim());
      dlg.style.display = "none";
      try { alert("Đã lưu cài đặt API/Proxy."); } catch {}
    };

    // refresh Gemini models
    dlg.querySelector("#ps-gemini-refresh").onclick = async () => {
      try {
        const $ = (s) => dlg.querySelector(s);
        const proxyUrl = $("#ps-proxy").value.trim() || getKV("proxy_url","");
        const apiKey   = $("#ps-gemini-key").value.trim() || getKV("gemini_key", window.ENV?.GOOGLE_API_KEY || "");
        const res = await callProxy({ proxyUrl, provider: "gemini", apiKey, body: { listModels: true } });
        if (!res.ok) throw new Error("Không lấy được models Gemini: " + (res.status || res.error || ""));
        const list = document.getElementById("dl-gemini-models");
        list.innerHTML = "";
        const models = (res.data?.models || res.data?.data || []);
        models.forEach(m => {
          const name = m.name || m.id || "";
          if (!name) return;
          const opt = document.createElement("option");
          opt.value = name;
          list.appendChild(opt);
        });
        alert("Đã nạp danh sách model Gemini.");
      } catch (err) {
        alert(err.message || String(err));
      }
    };

    // refresh Perplexity models
    dlg.querySelector("#ps-pplx-refresh").onclick = async () => {
      try {
        const $ = (s) => dlg.querySelector(s);
        const proxyUrl = $("#ps-proxy").value.trim() || getKV("proxy_url","");
        const apiKey   = $("#ps-pplx-key").value.trim() || getKV("pplx_key", window.ENV?.PPLX_API_KEY || "");
        const res = await callProxy({ proxyUrl, provider: "perplexity", apiKey, body: { listModels: true } });
        if (!res.ok) throw new Error("Không lấy được models Perplexity: " + (res.status || res.error || ""));
        const list = document.getElementById("dl-pplx-models");
        list.innerHTML = "";
        const models = (res.data?.data || res.data?.models || []);
        models.forEach(m => {
          const id = m.id || m.name || "";
          if (!id) return;
          const opt = document.createElement("option");
          opt.value = id;
          list.appendChild(opt);
        });
        alert("Đã nạp danh sách model Perplexity.");
      } catch (err) {
        alert(err.message || String(err));
      }
    };

    // mount
    dock.appendChild(openBtn);
    document.body.appendChild(dock);
    document.body.appendChild(dlg);
  }

  window.addEventListener("DOMContentLoaded", renderPanel);
})();

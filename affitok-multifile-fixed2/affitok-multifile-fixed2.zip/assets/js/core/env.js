window.ENV = {
  GOOGLE_API_KEY: "AIzaSyBhxEX-_kzF5RFrx3v3GOg6p5suTvZNOho",
  GEMINI_MODEL: "gemini-2.0-flash"
};

// assets/js/pages/prompt-studio.js
(function () {
  const SELECTORS = {
    inputTitle: '#ps-title',
    inputGoal: '#ps-goal',
    inputNotes: '#ps-notes',
    outputBox: '#ps-output',
    generateBtn: '#ps-generate-btn',
    mountPoint: '#prompt-studio-root'
  };

  function el(sel) { return document.querySelector(sel); }

  function ensureUI() {
    // If page already has inputs/outputs by ID, use them. Otherwise, mount a minimal UI.
    let root = document.querySelector(SELECTORS.mountPoint);
    if (!root) {
      root = document.createElement('div');
      root.id = 'prompt-studio-root';
      root.style = 'margin-top:16px;';
      root.innerHTML = `
        <div class="card">
          <div class="card__header">
            <h2 class="card__title">Prompt Studio</h2>
            <button class="btn btn-primary" id="ps-generate-btn">Generate (Ctrl+Enter)</button>
          </div>
          <div class="card__body">
            <div class="grid" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
              <div>
                <label class="form-label">Tiêu đề / Sản phẩm</label>
                <input id="ps-title" class="form-control" placeholder="Ví dụ: Máy lọc nước RO 9 lõi..." />
                <label class="form-label" style="margin-top:12px;">Mục tiêu</label>
                <input id="ps-goal" class="form-control" placeholder="Review/UGC/Live stream..." />
                <label class="form-label" style="margin-top:12px;">Ghi chú</label>
                <textarea id="ps-notes" class="form-control" rows="6" placeholder="USP, đối tượng, thông điệp..."></textarea>
              </div>
              <div>
                <label class="form-label">Kết quả</label>
                <textarea id="ps-output" class="form-control" rows="12" placeholder="(Sẽ xuất ra ở đây)"></textarea>
              </div>
            </div>
          </div>
        </div>
      `;
      const content = document.querySelector('main.content') || document.body;
      content.appendChild(root);
    }
  }

  async function loadAffiliateKnowledge() {
    try {
      const res = await fetch('./assets/mock/affiliate-knowledge.json', { cache: 'no-cache' });
      return await res.json();
    } catch (e) {
      console.warn('[PromptStudio] Không tải được affiliate-knowledge.json', e);
      return { guidelines: [], vocab: {}, frameworks: [], compliance: [] };
    }
  }

  function buildSystemPrompt(aff) {
    // Compact system instruction leveraging affiliate knowledge
    const blocks = [];
    if (aff?.guidelines?.length) {
      blocks.push('Affiliate Guidelines:\n- ' + aff.guidelines.map(x => x.title ? `${x.title}: ${x.points.join('; ')}` : x).join('\n- '));
    }
    if (aff?.frameworks?.length) {
      blocks.push('Frameworks: ' + aff.frameworks.map(f => f.name).join(', '));
    }
    if (aff?.compliance?.length) {
      blocks.push('Compliance: ' + aff.compliance.join('; '));
    }
    return [
      'Bạn là chuyên gia prompt engineering cho video review Affiliate bằng tiếng Việt.',
      'Luôn xuất ra JSON hợp lệ theo schema.',
      blocks.join('\n')
    ].join('\n\n');
  }

  function getSchema() {
    return {
      type: "object",
      properties: {
        prompt: { type: "string" },
        tips: { type: "array", items: { type: "string" } },
        guardrails: { type: "array", items: { type: "string" } },
        veo31: {
          type: "object",
          properties: {
            shotlist: { type: "array", items: { type: "string" } },
            product_sync: {
              type: "object",
              properties: {
                name: { type: "string" },
                key_features: { type: "array", items: { type: "string" } },
                price_hint: { type: "string" }
              }
            },
            reviewer: {
              type: "object",
              properties: {
                nationality: { type: "string" },
                tone: { type: "string" }
              }
            },
            hooks: { type: "array", items: { type: "string" } }
          }
        }
      },
      required: ["prompt"]
    };
  }

  async function onGenerate() {
    const title = (el(SELECTORS.inputTitle)?.value || '').trim();
    const goal = (el(SELECTORS.inputGoal)?.value || '').trim();
    const notes = (el(SELECTORS.inputNotes)?.value || '').trim();
    const outputBox = el(SELECTORS.outputBox);
    if (outputBox) outputBox.value = 'Đang tạo prompt...';

    const aff = await loadAffiliateKnowledge();
    const system = buildSystemPrompt(aff);
    const userInput = [
      title && `Sản phẩm: ${title}`,
      goal && `Mục tiêu: ${goal}`,
      notes && `Ghi chú: ${notes}`,
      'Yêu cầu: Áp dụng kiến thức affiliate ở trên. Thêm cấu trúc "veo31" để đồng bộ sản phẩm & người review (Việt Nam), thể loại affiliate & câu tương tác.'
    ].filter(Boolean).join('\n');

    try {
      const json = await GeminiService.generateJSON({
        system,
        input: userInput,
        schema: getSchema(),
        temperature: 0.2,
        maxOutputTokens: 2048
      });
      const result = JSON.stringify(json, null, 2);
      if (outputBox) outputBox.value = result;
      copyBtnSetup(result);
    } catch (e) {
      console.error(e);
      if (outputBox) outputBox.value = 'Lỗi tạo prompt: ' + e.message;
    }
  }

  function copyBtnSetup(text) {
    let btn = document.getElementById('ps-copy-btn');
    if (!btn) {
      btn = document.createElement('button');
      btn.id = 'ps-copy-btn';
      btn.className = 'btn btn-secondary';
      btn.style = 'position:fixed; right:16px; bottom:16px; z-index:9999;';
      btn.textContent = 'Copy JSON';
      document.body.appendChild(btn);
    }
    btn.onclick = async () => {
      try {
        await navigator.clipboard.writeText(text);
        btn.textContent = 'Đã copy!';
        setTimeout(() => (btn.textContent = 'Copy JSON'), 1200);
      } catch {}
    };
  }

  function setupHotkey() {
    window.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'enter') {
        e.preventDefault();
        onGenerate();
      }
    });
  }

  function mountGenerateButton() {
    let btn = document.querySelector(SELECTORS.generateBtn);
    if (!btn) {
      btn = document.createElement('button');
      btn.id = 'ps-generate-btn';
      btn.className = 'btn btn-primary';
      btn.style = 'position:fixed; right:16px; bottom:56px; z-index:9999;';
      btn.innerHTML = '<i class="ri-sparkling-2-line"></i> Generate (Ctrl+Enter)';
      document.body.appendChild(btn);
    }
    btn.addEventListener('click', onGenerate);
  }

  window.addEventListener('DOMContentLoaded', () => {
    ensureUI();
    mountGenerateButton();
    setupHotkey();
  });
})();

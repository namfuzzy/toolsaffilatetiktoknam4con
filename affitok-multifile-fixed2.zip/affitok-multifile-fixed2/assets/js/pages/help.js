function initAccordion(){console.log('initAccordion run');}

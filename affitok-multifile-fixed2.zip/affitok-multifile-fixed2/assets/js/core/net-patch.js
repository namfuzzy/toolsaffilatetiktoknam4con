
// === Network Resilience Patch (non-UI) ===
(function(){
  const CORS_PROXY = "https://cors.isomorphic-git.org/";
  function withTimeout(promise, ms){
    return new Promise((resolve, reject)=>{
      const t = setTimeout(()=>reject(new Error("timeout")), ms);
      promise.then(v => { clearTimeout(t); resolve(v); }, e => { clearTimeout(t); reject(e); });
    });
  }
  async function tryOnce(url, options){
    const opts = Object.assign({ method: "GET" }, options || {});
    if (opts.body && typeof opts.body === "object" && !(opts.body instanceof FormData)) {
      opts.headers = Object.assign({ "Content-Type": "application/json" }, opts.headers || {});
      opts.body = JSON.stringify(opts.body);
    }
    return withTimeout(fetch(url, opts), opts.timeout || 15000);
  }
  async function robustFetch(url, options){
    try {
      return await tryOnce(url, options);
    } catch(e){
      try {
        const proxied = (url.startsWith("http") ? CORS_PROXY + url : url);
        return await tryOnce(proxied, options);
      } catch(e2){
        const fallback = Object.assign({}, options || {});
        fallback.method = fallback.method || "GET";
        fallback.cache = "no-store";
        return await tryOnce(url, fallback);
      }
    }
  }
  window.robustFetch = robustFetch;
})();

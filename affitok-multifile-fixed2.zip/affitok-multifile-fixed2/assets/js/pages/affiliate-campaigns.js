function initAffCampaignsPage(){console.log('initAffCampaignsPage run');}

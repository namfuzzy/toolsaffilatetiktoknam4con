function initAffReportsPage(){console.log('initAffReportsPage run');}

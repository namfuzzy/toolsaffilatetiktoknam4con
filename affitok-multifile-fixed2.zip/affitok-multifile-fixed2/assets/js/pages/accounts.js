function initAccountsPage(){console.log('initAccountsPage run');}

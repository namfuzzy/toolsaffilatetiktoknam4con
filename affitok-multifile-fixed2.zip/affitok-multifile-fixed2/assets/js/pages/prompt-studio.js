// assets/js/pages/prompt-studio.js
(function () {
  // ====== SELECTORS & UTILS ======
  const SEL = {
    // UI mới (nếu có)
    psTitle: '#ps-title',
    psGoal: '#ps-goal',
    psNotes: '#ps-notes',
    psOutput: '#ps-output',
    psGenerate: '#ps-generate-btn',
    // UI sẵn có trong HTML gốc
    name: '#prompt-name',
    goal: '#prompt-goal',
    editor: '#prompt-editor',
    footerGenerate: '#btn-generate',
    mount: '#prompt-studio-root',
  };

  const $ = (s) => document.querySelector(s);

  // ====== SETTINGS / KV (ĐÃ SỬA CHO KHỚP settings-mini.js) ======
  function cfgGet(key, def) {
    try { return (window.KV && KV.get(key, def)) ?? def } catch { return def }
  }
  function loadCfg() {
    return {
      provider:    cfgGet('provider',    window.ENV?.DEFAULT_PROVIDER || 'gemini'), // 'gemini' | 'perplexity'
      // KHỚP key đã lưu từ settings-mini.js
      googleApiKey: cfgGet('gemini_key',  window.ENV?.GOOGLE_API_KEY || ''),
      geminiModel:  cfgGet('gemini_model', window.ENV?.GEMINI_MODEL   || 'gemini-2.5-pro'),
      pplxApiKey:   cfgGet('pplx_key',     window.ENV?.PPLX_API_KEY   || ''),
      pplxModel:    cfgGet('pplx_model',   window.ENV?.PPLX_MODEL     || 'sonar-small-chat'),
      gasProxy:     cfgGet('proxy_url',    window.ENV?.PROXY_URL      || ''),
    }
  }

  // Đảm bảo có chỗ hiển thị output & nút Generate nếu trang trống
  function ensureUI() {
    let out = $(SEL.psOutput);
    if (!out) {
      const box = document.createElement('div');
      box.id = 'ps-output-box';
      box.style = 'position:fixed; right:16px; bottom:92px; width:540px; max-height:60vh; z-index:9999; display:none;';
      box.innerHTML = `
        <div style="background:var(--bg-surface,#0f172a); color:#e2e8f0; border:1px solid rgba(148,163,184,.2); border-radius:12px; overflow:hidden; box-shadow:0 10px 30px rgba(0,0,0,.35)">
          <div style="padding:10px 12px; display:flex; align-items:center; gap:8px; border-bottom:1px solid rgba(148,163,184,.16)">
            <strong style="font-size:14px">Kết quả (JSON)</strong>
            <button id="ps-output-download" class="btn btn-secondary">Tải .json</button>
            <button id="ps-copy-btn" class="btn btn-secondary">Copy JSON</button>
            <button id="ps-close-out" class="btn btn-secondary">Đóng</button>
          </div>
          <pre id="ps-output" style="margin:0; padding:12px; font-size:12px; line-height:1.45; max-height:48vh; overflow:auto; background:transparent;"></pre>
        </div>`;
      document.body.appendChild(box);
      $('#ps-close-out').onclick = () => (box.style.display = 'none');
      $('#ps-output-download').onclick = () => {
        const text = $('#ps-output')?.textContent || ''
        const blob = new Blob([text], { type: 'application/json' })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url; a.download = 'prompt.json'; a.click()
        URL.revokeObjectURL(url)
      }
    }

    // nếu chưa có FAB generate, tạo luôn
    let gen = $(SEL.psGenerate);
    if (!gen) {
      gen = document.createElement('button');
      gen.id = 'ps-generate-btn';
      gen.className = 'btn btn-primary';
      gen.style = 'position:fixed; right:16px; bottom:16px; z-index:9999;';
      gen.innerHTML = '<i class="ri-sparkling-2-line"></i> Generate (Ctrl+Enter)';
      document.body.appendChild(gen);
    }
  }

  // ====== AFFILIATE KNOWLEDGE ======
  async function loadAffiliateKnowledge() {
    try {
      const res = await fetch('./assets/mock/affiliate-knowledge.json', { cache: 'no-cache' });
      return await res.json();
    } catch (e) {
      console.warn('[PromptStudio] Không tải được affiliate-knowledge.json', e);
      return { guidelines: [], vocab: {}, frameworks: [], compliance: [] };
    }
  }

  function buildSystemPrompt(aff) {
    const blocks = [];
    if (aff?.guidelines?.length) {
      blocks.push(
        'Affiliate Guidelines:\n- ' +
          aff.guidelines
            .map((x) => (x.title ? `${x.title}: ${Array.isArray(x.points) ? x.points.join('; ') : ''}` : x))
            .join('\n- ')
      );
    }
    if (aff?.frameworks?.length) {
      blocks.push('Frameworks: ' + aff.frameworks.map((f) => f.name).join(', '));
    }
    if (aff?.compliance?.length) {
      blocks.push('Compliance: ' + aff.compliance.join('; '));
    }
    return [
      'Bạn là chuyên gia prompt engineering cho video review Affiliate bằng tiếng Việt.',
      'Luôn xuất ra JSON hợp lệ theo schema.',
      blocks.join('\n'),
    ]
      .filter(Boolean)
      .join('\n\n');
  }

  // ====== SCHEMA (VEO 3.1 + affiliate fields) ======
  function getSchema() {
    return {
      type: 'object',
      properties: {
        prompt: { type: 'string' },
        tips: { type: 'array', items: { type: 'string' } },
        guardrails: { type: 'array', items: { type: 'string' } },
        veo31: {
          type: 'object',
          properties: {
            shotlist: { type: 'array', items: { type: 'string' } },
            product_sync: {
              type: 'object',
              properties: {
                name: { type: 'string' },
                key_features: { type: 'array', items: { type: 'string' } },
                price_hint: { type: 'string' },
              },
            },
            reviewer: {
              type: 'object',
              properties: {
                nationality: { type: 'string' },
                tone: { type: 'string' },
              },
            },
            hooks: { type: 'array', items: { type: 'string' } },
          },
        },
      },
      required: ['prompt'],
    };
  }

  // ====== SERVICE CHỌN THEO PROVIDER (giữ nguyên gọi services/*) ======
  function getGeneratorByProvider(provider) {
    if (provider === 'perplexity') {
      if (!window.PerplexityService?.generateJSON) {
        throw new Error('Perplexity service chưa sẵn sàng. Kiểm tra assets/js/services/perplexity.js')
      }
      return 'perplexity'
    }
    // mặc định Gemini
    const g =
      (window.Gemini && window.Gemini.generateJSON) ||
      (window.GeminiService && window.GeminiService.generateJSON);
    if (!g) {
      throw new Error('Gemini service chưa sẵn sàng. Kiểm tra assets/js/services/gemini.js & ENV.')
    }
    return 'gemini'
  }

  // ====== IO HELPERS ======
  function readInputs() {
    const name = ($(SEL.name)?.value || $(SEL.psTitle)?.value || '').trim();
    const goal = ($(SEL.goal)?.value || $(SEL.psGoal)?.value || '').trim();
    const notes = ($(SEL.editor)?.value || $(SEL.psNotes)?.value || '').trim();
    return { name, goal, notes };
  }

  function showOutput(text) {
    const out = $(SEL.psOutput);
    const box = $('#ps-output-box');
    if (out) {
      out.textContent = text;
      if (box) box.style.display = 'block';
    } else if (box) {
      const pre = document.createElement('pre');
      pre.id = 'ps-output';
      pre.style.cssText =
        'margin:0; padding:12px; font-size:12px; line-height:1.45; max-height:48vh; overflow:auto;';
      pre.textContent = text;
      box.querySelector('div').appendChild(pre);
      box.style.display = 'block';
    }
    const copyBtn = $('#ps-copy-btn');
    if (copyBtn) {
      copyBtn.onclick = async () => {
        try {
          await navigator.clipboard.writeText(text);
          copyBtn.textContent = 'Đã copy!';
          setTimeout(() => (copyBtn.textContent = 'Copy JSON'), 1200);
        } catch {}
      };
    }
  }

  function setButtonsDisabled(disabled) {
    [SEL.psGenerate, SEL.footerGenerate]
      .map((s) => $(s))
      .filter(Boolean)
      .forEach((b) => {
        b.disabled = !!disabled;
        b.classList.toggle('is-loading', !!disabled);
      });
  }

  // ====== GENERATE CORE ======
  async function onGenerate(ev) {
    if (ev) ev.preventDefault();

    try {
      const { name, goal, notes } = readInputs();
      if (!name && !goal && !notes) {
        alert('Vui lòng nhập ít nhất một trường (Tên/Mục tiêu/Nội dung).');
        return;
      }

      const cfg = loadCfg()
      const provider = getGeneratorByProvider(cfg.provider)

      // Cảnh báo nhanh nếu thiếu key
      if (provider === 'perplexity' && !cfg.pplxApiKey) {
        alert('Thiếu Perplexity API Key trong ⚙ API.');
        return;
      }
      if (provider === 'gemini' && !cfg.googleApiKey) {
        alert('Thiếu Gemini API Key trong ⚙ API.');
        return;
      }

      setButtonsDisabled(true);
      showOutput('Đang tạo prompt...');

      const aff = await loadAffiliateKnowledge();
      const system = buildSystemPrompt(aff);
      const userInput = [
        name && `Sản phẩm: ${name}`,
        goal && `Mục tiêu: ${goal}`,
        notes && `Nội dung/Ghi chú: ${notes}`,
        'Yêu cầu: Áp dụng kiến thức affiliate ở trên. Thêm cấu trúc "veo31" để đồng bộ sản phẩm & người review (Việt Nam), thể loại affiliate & câu tương tác.',
      ].filter(Boolean).join('\n');

      let json
      if (provider === 'perplexity') {
        json = await window.PerplexityService.generateJSON({
          input: userInput,
          schema: getSchema(),
          model: cfg.pplxModel,
          apiKey: cfg.pplxApiKey,
          temperature: 0.2
        })
      } else {
        // Gemini
        const gen =
          (window.Gemini && window.Gemini.generateJSON) ||
          (window.GeminiService && window.GeminiService.generateJSON)

        json = await gen({
          system,
          input: userInput,
          schema: getSchema(),
          model: cfg.geminiModel,
          apiKey: cfg.googleApiKey,
          proxy: cfg.gasProxy,    // có thể để trống nếu không dùng GAS
          temperature: 0.2,
          maxOutputTokens: 2048,
        })
      }

      const pretty = JSON.stringify(json, null, 2);
      showOutput(pretty);
      setButtonsDisabled(false);
    } catch (err) {
      console.error(err);
      setButtonsDisabled(false);
      showOutput('Lỗi tạo prompt: ' + (err?.message || err));
      alert('Lỗi khi gọi model: ' + (err?.message || err));
    }
  }

  // ====== WIRING ======
  function wireButtons() {
    const fab = $(SEL.psGenerate);
    const footer = $(SEL.footerGenerate);

    if (fab && footer) footer.style.display = 'none';

    [fab, footer].filter(Boolean).forEach((btn) => {
      if (btn._wired) return;
      btn._wired = true;
      btn.disabled = false;
      btn.addEventListener('click', onGenerate);
    });

    // Phím tắt Ctrl/Cmd + Enter
    document.addEventListener('keydown', (e) => {
      const isMac = navigator.platform.toLowerCase().includes('mac');
      if ((isMac ? e.metaKey : e.ctrlKey) && e.key.toLowerCase() === 'enter') {
        e.preventDefault();
        onGenerate(e);
      }
    });
  }

  // ====== BOOT ======
  function boot() {
    ensureUI();
    wireButtons();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();

// assets/js/services/gemini.js
(function (global) {
  const API_HOST = "https://generativelanguage.googleapis.com";
  const API_VERSION = "v1beta";

  function ensureEnv() {
    if (!global.window || !global.window.ENV) throw new Error("ENV is missing. Please include assets/js/core/env.js before services.");
    if (!window.ENV.GOOGLE_API_KEY) console.warn("[GeminiService] GOOGLE_API_KEY is empty. You must fill it in assets/js/core/env.js");
    return window.ENV;
  }

  async function callGemini(model, body) {
    const env = ensureEnv();
    const key = env.GOOGLE_API_KEY;
    const url = `${API_HOST}/${API_VERSION}/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    if (!res.ok) {
      const t = await res.text();
      throw new Error(`[GeminiService] HTTP ${res.status} ${res.statusText}: ${t}`);
    }
    return res.json();
  }

  function toPart(obj) {
    if (!obj) return null;
    if (typeof obj === "string") return { text: obj };
    if (obj.inline_data) return { inline_data: obj.inline_data };
    if (obj.text) return { text: obj.text };
    return null;
  }

  const GeminiService = {
    /** Generate free-form text with optional images. */
    async generateText({ system, input, images = [], temperature = 0.3, maxOutputTokens = 2048 } = {}) {
      const { GEMINI_MODEL } = ensureEnv();

      const parts = [];
      if (system) parts.push(toPart(`SYSTEM:\n${system}`));
      if (input) parts.push(toPart(input));
      if (images && images.length) {
        for (const img of images) {
          // img = { mimeType, dataBase64 }
          parts.push({ inline_data: { mime_type: img.mimeType, data: img.dataBase64 } });
        }
      }

      const body = {
        contents: [{ role: "user", parts }],
        generationConfig: {
          temperature,
          maxOutputTokens
        }
      };

      const json = await callGemini(GEMINI_MODEL, body);
      const text = (((json || {}).candidates || [])[0] || {}).content?.parts?.[0]?.text || "";
      return text;
    },

    /** Generate JSON according to a responseSchema (JSON Mode). */
    async generateJSON({ system, input, schema, images = [], temperature = 0.2, maxOutputTokens = 2048 } = {}) {
      const { GEMINI_MODEL } = ensureEnv();

      const parts = [];
      if (system) parts.push(toPart(`SYSTEM:\n${system}`));
      if (input) parts.push(toPart(input));
      if (images && images.length) {
        for (const img of images) {
          parts.push({ inline_data: { mime_type: img.mimeType, data: img.dataBase64 } });
        }
      }

      const body = {
        contents: [{ role: "user", parts }],
        generationConfig: {
          temperature,
          maxOutputTokens,
          responseMimeType: "application/json",
          ...(schema ? { responseSchema: schema } : {})
        }
      };

      const json = await callGemini(GEMINI_MODEL, body);
      const text = (((json || {}).candidates || [])[0] || {}).content?.parts?.[0]?.text || "{}";
      try {
        return JSON.parse(text);
      } catch (e) {
        console.warn("[GeminiService] JSON parse failed. Raw text:", text);
        return { _raw: text, _error: "Invalid JSON from model" };
      }
    }
  };

  // UMD-ish export
  if (typeof module !== "undefined" && module.exports) module.exports = GeminiService;
  else global.GeminiService = GeminiService;
})(this);

function initAffNetworksPage(){console.log('initAffNetworksPage run');}

function initAffLinkBuilder(){console.log('initAffLinkBuilder run');}
